export default function Login({func}){

   

   return<>
    <p>login form</p>
    <input onInput={(event) => func(event.target.value)}/>
   </>
}