import BaseFrame from "../components/theme/BaseFrame";
import StockItem from "../components/theme/StockItem";

export default function Transaction() {
    var items = [
        {
            title: 'Paypal',
            type: 'Send money',
            img: 'paypal.png',
            value: '+82.6'
        },
        {
            title: 'Wallet',
            type: 'Mac\'D',
            img: 'wallet.png',
            value: '+270.69'
        },

        {
            title: 'Transfer',
            type: 'Refund',
            img: 'chart.png',
            value: '+637.91'
        },

        {
            title: 'Credit Card',
            type: 'Ordered Food',
            img: 'cc-success.png',
            value: '-838.71'
        },

        {
            title: 'Wallet',
            type: 'Starbucks',
            img: 'wallet.png',
            value: '+203.33'
        },

        {
            title: 'Mastercard',
            type: 'Ordered Food',
            img: 'cc-warning.png',
            value: '-92.45'
        }
    ]
    return <>
        <BaseFrame title="hello" subtitle={"how are"} customClass="col-md-6 col-lg-8 col-xl-8 order-0 mb-4">
            <ul class="p-0 m-0 mt-4">
                {
                    items.map(item => {
                        return <StockItem info = {item} />
                    })
                }
            </ul>
        </BaseFrame>
    </>
}