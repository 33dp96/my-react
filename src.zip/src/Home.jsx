import logo from './logo.svg';
import './App.css';
import './style.css'
import Message from './components/message';
import Card from './components/Card';
import Sidebar from './components/theme/Sidebar';
import Nav from './components/theme/Nav';
import BaseFrame from './components/theme/BaseFrame';
import Main from './components/theme/Main';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';

export default function Home() {
    var products = [
        {
            name: 'samsung',
            img: 'logo192.png',
            desc: 'گوشی تمیز در حد آک'
        },
        {
            name: 'apple',
            img: 'logo512.png',
            desc: 'ببری ضرر نمیکنی'
        },
    ]

    return (<>

        <div className="layout-wrapper layout-content-navbar">
            <div className="layout-container">
                <Sidebar />
                <div className="layout-page">
                    
                    <Nav />
                    <Main />
                </div>
            </div>
        </div>
    </>
    );
}
