export default function Changenum({func}) {
    
    return <>
        <button onClick={() => func('inc')}>+</button>
        <br />
        <button onClick={() => func('dec')}>-</button>
    </>
}