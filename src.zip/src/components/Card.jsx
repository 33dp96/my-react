import Message from "./message";

export default function Card({ src, title, description }) {
    return (<div className="card" style={{ width: "18rem" }}>
        <img src={src} className="card-img-top" alt="..." />
        <div className="card-body">
            <Message word={title} />
            <p className="card-text">{description}</p>
            <a href="#" className="btn btn-primary">Go somewhere</a>
        </div>
    </div>
    )
}