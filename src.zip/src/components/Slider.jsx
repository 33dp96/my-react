import { Navigation, Pagination, Scrollbar, A11y } from 'swiper/modules';

import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';

export default function Slider() {
    var slides = [
        {
            title: 'Card title',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This'
                + 'content is a little bit longer.',
            img: '11.jpg',
            publish_date: 'Last updated 3 mins ago'
        },

        {
            title: 'samsung',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This',

            img: '1.jpg',
            publish_date: 'Last updated 3 mins ago'
        },

        {
            title: 'apple',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This'
                + 'content is a little bit longer.',
            img: '12.jpg',
            publish_date: 'Last updated 3 mins ago'
        },

        {
            title: 'verto',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This'
                + 'content is a little bit longer.',
            img: '4.jpg',
            publish_date: 'Last updated 3 mins ago'
        }
    ]
    return (
        <div className="container mb-5">
            <Swiper
                // install Swiper modules
                modules={[Navigation, Pagination, Scrollbar, A11y]}
                spaceBetween={10}
                slidesPerView={3}
                navigation
                pagination={{ clickable: true }}
                //scrollbar={{ draggable: true }}
                onSwiper={(swiper) => console.log(swiper)}
                onSlideChange={() => console.log('slide change')}
            >

                {
                    slides?.map(function (item) {
                        return <SwiperSlide>
                            <div className="card bg-dark border-0 text-white">
                                <img className="card-img" src={"/assets/img/elements/" + item.img} alt="Card image" />
                                <div className="card-img-overlay">
                                    <h5 className="card-title">{item.title}</h5>
                                    <p className="card-text">
                                        {item.description}
                                    </p>
                                    <p className="card-text">{item.publish_date}</p>
                                </div>
                            </div>
                        </SwiperSlide>
                    })
                }

            </Swiper>
        </div>
    );
}