import { useState } from "react"
import BaseFrame from "../theme/BaseFrame"
export default function TodoLists() {
    const [title, setTitle] = useState()
    const [description, setDescription] = useState()

    const [todoes, setTodoes] = useState([
        {
            id: 1,
            title: 'تماشای فیلم',
            description: 'فیلم ارباب حلقه ها'
        },

        {
            id: 2,
            title: 'تمرین ری اکت',
            description: 'مرور جلسات گذشته'
        }
    ])
    

    function save(event) {
        event.preventDefault();
        setTodoes([...todoes, {title: title, description: description}])
        //console.log(title, description);

    }
    return <>
        <div className="container">
            <div className="row">
                <BaseFrame title={'کارهای پیش رو'}>
                    <div className="accordion mt-3" id="accordionExample">
                        {
                            todoes?.map((item, index) => {
                                return <div className="card accordion-item">
                                    <h2 className="accordion-header" id={"heading-" + index}>
                                        <button type="button" className="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target={"#accordion-" + index} aria-expanded="false" aria-controls={"accordion-" + index}>
                                            {item.title}
                                        </button>
                                    </h2>

                                    <div id={"accordion-" + index} className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div className="accordion-body">
                                            {item.description}
                                        </div>
                                    </div>
                                </div>
                            })
                        }
                    </div>
                </BaseFrame>
                <BaseFrame title={'ایجاد تسک جدید'}>
                    <form onSubmit={(event) => save(event)}>
                        <input type="text" onInput={(event) => setTitle(event.target.value)} />
                        <label htmlFor="">عنوان وظیفه</label>
                        <br />
                        <textarea name="" id="" onInput={(event) => setDescription(event.target.value)}></textarea>
                        <label htmlFor="">توضیح وظیفه</label>
                        <br />
                        <button>ثبت</button>
                    </form>
                </BaseFrame>

            </div>
        </div>
    </>
}