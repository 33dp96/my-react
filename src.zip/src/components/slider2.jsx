import { Navigation, Pagination, Scrollbar, A11y, Autoplay} from 'swiper/modules';

import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
export default function Swiperslider() {
    var slides = [
        {
            title: 'Card title',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This'
                + 'content is a little bit longer.',
            img: '11.jpg',
            publish_date: 'Last updated 3 mins ago'
        },

        {
            title: 'samsung',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This',

            img: '1.jpg',
            publish_date: 'Last updated 3 mins ago'
        },

        {
            title: 'apple',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This'
                + 'content is a little bit longer.',
            img: '12.jpg',
            publish_date: 'Last updated 3 mins ago'
        },

        {
            title: 'verto',
            description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This'
                + 'content is a little bit longer.',
            img: '4.jpg',
            publish_date: 'Last updated 3 mins ago'
        }
    ]
    return <>

        <div className="container mb-5">
            <Swiper
                // install Swiper modules
                modules={[Navigation, Pagination, Scrollbar, A11y, Autoplay]}
                spaceBetween={10}
                autoplay= {true}
                slidesPerView={3}
                navigation
                pagination={{ clickable: true }}
                //scrollbar={{ draggable: true }}
                onSwiper={(swiper) => console.log(swiper)}
                onSlideChange={() => console.log('slide change')}
                allowTouchMove={false}
                
                
            >

                {
                    slides?.map(function (item) {
                        return <SwiperSlide>
                            <div className="card h-100">
                                <div className="card-body">
                                    <h5 className="card-title">{item.title}</h5>
                                    <h6 className="card-subtitle text-muted">{item.description}</h6>
                                </div>
                                <img className="img-fluid" src={"/assets/img/elements/" + item.img} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-text">Bear claw sesame snaps gummies chocolate.</p>
                                    <a href="javascript:void(0);" className="card-link">Card link</a>
                                    <a href="javascript:void(0);" className="card-link">Another link</a>
                                </div>
                            </div>
                        </SwiperSlide>
                    })
                }

            </Swiper>
        </div>

    </>
}