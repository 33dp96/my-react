import { useState } from "react";
import Changenum from "./changenum";

export default function Message({ word = 'hi how are you?', func }) {

    //function change_word(){

    //}

    //var message = "bye"
    const [message, setMessage] = useState('ghj');

    const change_word = (w) => {
        //message = w

        setMessage(w)
    }


    return (
        <div className="p-5">
            <h2 style={{ color: 'red' }}>{word}</h2>
            <h2 style={{ color: 'green' }}>{message}</h2>


            <button onClick={() => change_word('helelo')}>
                change message
            </button>
            <br />

            <button onClick={() => func('inc')}>+</button>
            <br />
            <button onClick={() => func('dec')}>-</button>
        </div>
    );

}