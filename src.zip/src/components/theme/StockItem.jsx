export default function StockItem({info}) {
    return <>
        <li className="d-flex mb-4 pb-1">
            <div className="avatar flex-shrink-0 me-3">
                <img alt="User" className="rounded" src={`/assets/img/icons/unicons/${info?.img}`} />
            </div>
            <div className="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                <div className="me-2">
                    <small className="text-muted d-block mb-1">{info?.title}</small>
                    <h6 className="mb-0">{info?.type}</h6>
                </div>
                <div className="user-progress d-flex align-items-center gap-1">
                    <h6 className="mb-0">{info?.value}</h6>
                    <span className="text-muted">USD</span>
                </div>
            </div>
        </li>
    </>
}