import Transaction from "../../financial/Transaction";
import BaseFrame from "./BaseFrame";

export default function Main() {
    return <>
        <div className="content-wrapper">
            <div className="container-xxl flex-grow-1 container-p-y">
                <div className="row">
                    <Transaction/>

                    <BaseFrame title={"bye"}>
                        <h2>hi</h2>
                    </BaseFrame>
                </div>
            </div>
        </div>

    </>
}