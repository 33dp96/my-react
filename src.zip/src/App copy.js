import logo from './logo.svg';
import './App.css';
import './style.css'
import Message from './components/message';
import Card from './components/Card';

export default function App() {
  var products = [
    {
      name: 'samsung',
      img: 'logo192.png',
      desc: 'گوشی تمیز در حد آک'
    },
    {
      name: 'apple',
      img: 'logo512.png',
      desc: 'ببری ضرر نمیکنی'
    },
  ]

  return (<>
    <div className="" style={{ display: "flex", margin: "auto" }}>

      {
        products.map(function (item) {
          return <Card title={item.name} src={item.img} description={item.desc} />
        })
      }
      <Card description={'hello how are you? i\'m fine and yo?'} src={"/assets/images/logo192.png"} title={'New Title'} />
      <Card description={'hello how are you? i\'m fine and yo?'} src={"/assets/images/logo192.png"} title={'Second Title'} />
    </div>
  </>
  );
}
